<script>
export default {
  asyncData({ redirect }) {
    redirect('/admin/films')
  }
}
</script>
