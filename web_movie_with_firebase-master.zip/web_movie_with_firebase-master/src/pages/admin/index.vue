<template>
  <div>hello admin</div>
</template>
